package com.payez.Payez;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PayezApplicationTests {

	@Test
	void contextLoads() {
	}

}
