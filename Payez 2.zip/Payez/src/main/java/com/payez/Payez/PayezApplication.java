package com.payez.Payez;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayezApplication {

	public static void main(String[] args) {
		SpringApplication.run(PayezApplication.class, args);
	}

}
